import { Component } from '@angular/core';

@Component({
  selector: 'app-file-search',
  imports: [],
  templateUrl: './file-search.component.html',
  styleUrl: './file-search.component.css'
})
export class FileSearchComponent {

}
