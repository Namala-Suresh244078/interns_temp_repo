import { Component } from '@angular/core';

@Component({
  selector: 'app-file-details',
  imports: [],
  templateUrl: './file-details.component.html',
  styleUrl: './file-details.component.css'
})
export class FileDetailsComponent {

}
