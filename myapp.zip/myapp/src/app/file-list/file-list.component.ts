import { Component } from '@angular/core';

@Component({
  selector: 'app-file-list',
  imports: [],
  templateUrl: './file-list.component.html',
  styleUrl: './file-list.component.css'
})
export class FileListComponent {

}
