import { Component } from '@angular/core';

@Component({
  selector: 'app-status-update',
  imports: [],
  templateUrl: './status-update.component.html',
  styleUrl: './status-update.component.css'
})
export class StatusUpdateComponent {

}
