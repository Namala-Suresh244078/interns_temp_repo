import { Component } from '@angular/core';

@Component({
  selector: 'app-file-info',
  imports: [],
  templateUrl: './file-info.component.html',
  styleUrl: './file-info.component.css'
})
export class FileInfoComponent {

}
